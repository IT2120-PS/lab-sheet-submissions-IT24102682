setwd("C:\\Users\\Akarsha\\Desktop\\IT24102682")
getwd()

#1
data <-read.table("Data.txt",header = TRUE,sep = ",")
fix(data)
attach(data)

names(data)<-c("X1","X2")
attach(data)
hist(X2,main = "Histogram for Number of Shareholders")

#2
histogram <- hist(X2,main ="Histogram for Number of Shareholders",breaks = seq(130,270,length=8),right = FALSE )
?hist

#3
breaks <- round(histogram$breaks)
freq <- histogram$counts
mids <- histogram$mids

classes <- c()

for(i in 1:length(breaks)-1){
  classes[i]<- paste0("[",breaks[i],",",breaks[i+1],"]")
}

cbind(Classes = classes,Frequency = freq)

#4
lines(mids,freq)
plot(mids,freq,type='l',main = "Frequency polygon for Shareholders",xlab = "Shareholders",ylab = "Frequency",ylim = c(0,max(freq)))

#5
cum.freq <- cumsum(freq)

new <- c()

for(i in 1:length(breaks)){
  if(i == 1){
    new[i] = 0
  } else {
    new[i] = cum.freq[i-1]
  }
}

# Draw cumulative frequency polygon (ogive) in a new plot
plot(breaks, new, type = 'l', main = "Cumulative Frequency Polygon for Shareholders", xlab = "Shareholders", ylab = "Cumulative Frequency", ylim = c(0, max(new)))
cbind(Upper = breaks,cumFreq = new)


#Lab Sheet 5
#1
Delivery_Times <- read.table("Exercise - Lab 05.txt", header=TRUE)
fix(Delivery_Times)
names(Delivery_Times)<-c("X4")
attach(Delivery_Times)

#2
histogram2 <-hist(X4,main = "Histogram for deliver times",breaks = seq(20,70,length=9,right=FALSE))

#4
breaks <- round(histogram2$breaks)
freq <- table(X4)
cum.freq <- cumsum(freq)

new <- c()

for(i in 1:length(breaks)){
  if(i == 1){
    new[i] = 0
  } else {
    new[i] = cum.freq[i-1]
  }
}

# Draw cumulative frequency polygon (ogive) in a new plot
plot(breaks, new, type = 'l', main = "Cumulative Frequency Polygon for Delivery Times", 
     xlab = "Delivery Times (minutes)", ylab = "Cumulative Frequency", 
     ylim = c(0, max(new)))